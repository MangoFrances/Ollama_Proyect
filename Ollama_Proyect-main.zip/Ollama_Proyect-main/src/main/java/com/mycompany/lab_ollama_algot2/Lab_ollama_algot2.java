package com.mycompany.lab_ollama_algot2;

public class Lab_ollama_algot2 {

    public static void main(String[] args) {
        // Variables para el modelo
        String nombremodelo = "gemma2:2b";
        String promptText = "What is life?";
        GUI frame= new GUI();
        frame.setVisible(true);
        frame.setSize(712, 730);
    }
        
 
}

