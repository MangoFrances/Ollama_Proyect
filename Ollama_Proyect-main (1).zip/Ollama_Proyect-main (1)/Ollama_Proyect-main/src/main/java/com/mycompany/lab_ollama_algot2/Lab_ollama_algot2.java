package com.mycompany.lab_ollama_algot2;

public class Lab_ollama_algot2 {

    public static void main(String[] args) {        
        GUI frame= new GUI();
        frame.setVisible(true);
        frame.setSize(716, 750);
    }
        
 
}

